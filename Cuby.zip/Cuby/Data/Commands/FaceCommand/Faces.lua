return {
    {ImageURL = "https://tr.rbxcdn.com/ec651b74203b9ce5a0b570076b70ce6a/420/420/Face/Png", Name = "Friendly Cyclops"},
    {ImageURL = "https://tr.rbxcdn.com/b8a81a6e18d8d88cf922a670142c14c1/420/420/Face/Png", Name = "Finn McCool"},
    {ImageURL = "https://tr.rbxcdn.com/6751f40ab62fa7129a791e5955fe59ee/420/420/Face/Png", Name = "$.$"},
    {ImageURL = "https://tr.rbxcdn.com/67cc9d1fe483eb931ad721de940b40ef/420/420/Face/Png", Name = "Crazy Happy"},
    {ImageURL = "https://tr.rbxcdn.com/b55723593c2b28c3d33ec0df7599d28f/420/420/Face/Png", Name = "Super Happy Joy"},
}