return function(Data)
    Data.PreMSG:setContent("Pong!")
end