# Anomalous Cuby
 
