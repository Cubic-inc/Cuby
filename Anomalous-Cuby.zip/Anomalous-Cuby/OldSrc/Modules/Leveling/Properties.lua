return {
    Name = "Leveling",
    Main = require("./Main.lua"),

    Commands = {
        Stats = require("./Commands/Stats.lua")
    }
}