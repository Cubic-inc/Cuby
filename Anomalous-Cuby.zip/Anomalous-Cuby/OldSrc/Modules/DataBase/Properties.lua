return {
    Name = "Database manager",
    Main = require("./Main.lua"),

    Commands = {}
}