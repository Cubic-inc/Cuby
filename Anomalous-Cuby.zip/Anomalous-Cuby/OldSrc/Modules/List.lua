return {
    DataBase = require("./DataBase/Properties"),
    Leveling = require("./Leveling/Properties"),
    Fun = require("./Fun/Properties")
}