return {
    name = "CoreByte/Anomalous-Cuby",
    version = "0.0.0",
    dependencies = {
        "SinisterRectus/discordia  ",
        "SinisterRectus/sqlite3    ",
        "creationix/base64         ",
        "creationix/coro-channel   ",
        "creationix/coro-http      ",
        "creationix/coro-net       ",
        "creationix/coro-websocket ",
        "creationix/coro-wrapper   ",
        "creationix/pathjoin       ",
        "creationix/sha1           ",
        "creationix/websocket-codec",
        "luvit/http-codec          ",
        "luvit/resource            ",
        "luvit/secure-socket       "
    }
}