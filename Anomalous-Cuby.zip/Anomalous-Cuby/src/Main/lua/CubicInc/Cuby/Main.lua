print("Hello World!")

local Discordia = require("discordia")
require("discordia-interactions")
require("discordia-slash")
require("discordia-components")

local Client = Discordia.Client():useApplicationCommands()

